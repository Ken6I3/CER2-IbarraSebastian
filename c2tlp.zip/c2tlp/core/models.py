from django.db import models

# Create your models here.
class material(models.Model):
    codigo = models.CharField(max_length=5)
    nombre = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=400)

    def __str__(self):
        return self.codigo+"-"+self.nombre

class Usuario(models.Model):
    rut = models.CharField(max_length=12)
    nombre = models.CharField(max_length=100)
    correo = models.CharField(max_length=50)
    contraseña = models.CharField(max_length=25)
    direccion = models.CharField(max_length=80)
    telefono = models.CharField(max_length=30)

    def __str__(self):
        return self.rut+"-"+self.nombre

class Operador(models.Model):
    codigo = models.CharField(max_length=12)
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.codigo+"-"+self.nombre

class Staff(models.Model):
    codigo = models.CharField(max_length=12)
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.codigo+"-"+self.nombre

class Solicitud(models.Model):
    rut = models.CharField(max_length=12)
    cantidad = models.IntegerField()
    fecha = models.CharField(max_length=10)

    def __str__(self):
        return self.codigo+"-"+self.nombre