from django.contrib import admin
from .models import material
from .models import Usuario
from .models import Solicitud
# Register your models here.

admin.site.register(material)
admin.site.register(Usuario)
admin.site.register(Solicitud)
