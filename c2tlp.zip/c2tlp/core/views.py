from django.shortcuts import render
from django.contrib import messages
from django.http import HttpResponse
from .models import Usuario
from .models import material

# Create your views here.

def home(request):
    materiales = material.objects.all()
    return render(request, 'core/index.html', {'materiales': materiales})

def inicio(request):
    materiales = material.objects.all()
    if(request.POST):
        correo = request.POST["txtCorreo"]
        contraseña = request.POST["txtContra"]

        lista_usuarios = Usuario.objects.all()
        usuario_e = lista_usuarios.get(correo=correo)
        aux = False

        if not correo or not contraseña:
            messages.error(request, "Todos los campos son obligatorios")
            aux = True
        if usuario_e.correo == 0:
            messages.error(request, "El usuario no existe")
            aux = True
        else:
            if usuario_e.contraseña==contraseña:
                rut = usuario_e.rut
                return render(request,'core/index.html',{'rut':rut,'materiales':materiales})
        if aux:
            return render(request, 'core/inicio.html')
    return render(request, 'core/inicio.html')


def registro(request):
    if(request.POST):

        rut = request.POST["txtRut"]
        nombre = request.POST["txtNombre"]
        correo = request.POST["txtCorreo"]
        contraseña = request.POST["txtContra"]
        direccion = request.POST["txtDireccion"]
        telefono = request.POST["txtTelefono"]
       
        newUser = Usuario()
        newUser.rut = rut
        newUser.nombre = nombre
        newUser.correo = correo
        newUser.contraseña = contraseña
        newUser.direccion = direccion
        newUser.telefono = telefono

        aux = False

        if not rut or not nombre or not correo or not contraseña or not direccion or not telefono:
            messages.error(request, "Todos los campos son obligatorios")
            aux = True
        if Usuario.objects.filter(rut=rut).exists():
            messages.error(request, "Ya existe un usuario con ese RUT")
            aux = True
        if aux:
            return render(request, 'core/registro.html')
        
        newUser.save()
        messages.success(request, "Usuario creado exitosamente")
    return render(request, 'core/registro.html')

def solicitud_retiro(request):
    return render(request,'core/solicitud_retiro.html')