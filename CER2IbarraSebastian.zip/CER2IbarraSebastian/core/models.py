from django.db import models
from django.contrib.auth.models import User

class Perfil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    rut = models.CharField(max_length=12, unique=True)
    telefono = models.CharField(max_length=20)
    direccion = models.CharField(max_length=150)

    def __str__(self):
        return f"{self.user.username} - {self.rut}"

class Material(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=100)
    cantidad = models.PositiveIntegerField()

    def __str__(self):
        return self.nombre + " - " + self.codigo


class Solicitud(models.Model):
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    fecha_estimada = models.DateField()

    def __str__(self):
        return f"{self.material.nombre} - cantidad: {self.cantidad} - fecha: {self.fecha_estimada}"