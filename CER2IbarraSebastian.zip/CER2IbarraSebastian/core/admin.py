from django.contrib import admin
from .form import User
# Register your models here.

admin.site.unregister(User)