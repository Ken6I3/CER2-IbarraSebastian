from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.views import LoginView
from .form import FormRegistro

class CustomLoginView(LoginView):
    template_name = 'core/login.html'

def home(request):
    return render(request,'core/inicio.html')

def materiales(request):
    return render(request,'core/materiales.html')

def puntos_limpios(request):
    return render(request,'core/puntos_limpios.html')

def solicitudes(request):
    return render(request,'core/solicitudes.html')

def login(request):
    return render(request,'core/login.html')

def registro(request):
    if request.method == 'POST':
        form = FormRegistro(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('inicio')
    else:
        form = FormRegistro()
        return render(request, 'core/registro.html', {'form': form})